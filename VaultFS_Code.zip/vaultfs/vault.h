#ifndef VAULT_H
#define VAULT_H

#define VAULT_FILE   "vault.bin"
#define MAX_FILES    64
#define NAME_LEN     128
#define SALT_LEN     16
#define HASH_LEN     32
#define CHUNK_SIZE   4096
#define MAGIC        "VAULTFS1"

typedef struct {
    char          magic[8];
    unsigned char salt[SALT_LEN];
    unsigned char pass_hash[HASH_LEN];
    int           file_count;
} VaultHeader;

typedef struct {
    char name[NAME_LEN];
    long size;
    long offset;
    int  used;
} FileEntry;

/* vault.c */
int vault_init(void);
int vault_login(unsigned char *key);
int vault_add(const char *path, const unsigned char *key);
int vault_list(void);
int vault_extract(const char *name, const unsigned char *key);

/* crypto.c */
void generate_salt(unsigned char *salt, int len);
void hash_password(const char *password, const unsigned char *salt,
                   unsigned char *out_hash);
int  hash_equal(const unsigned char *a, const unsigned char *b, int len);
void derive_key(const char *password, const unsigned char *salt,
                unsigned char *key);
void encrypt_buffer(unsigned char *buf, int len,
                    const unsigned char *key, long pos);
void decrypt_buffer(unsigned char *buf, int len,
                    const unsigned char *key, long pos);

#endif
