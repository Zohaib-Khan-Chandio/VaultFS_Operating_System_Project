#!/bin/bash
# Removes build files; asks before deleting data

cd "$(dirname "$0")" || exit 1

make clean > /dev/null 2>&1
rm -f *.o vaultfs
echo "[ok] build files removed"

if [ -f vault.bin ]; then
    read -r -p "Also delete vault.bin and ALL its files? (yes/no): " ans
    if [ "$ans" = "yes" ]; then
        rm -f vault.bin
        echo "[ok] vault.bin deleted"
    else
        echo "vault.bin kept"
    fi
fi

if [ -d backups ]; then
    read -r -p "Also delete the backups folder? (yes/no): " ans
    if [ "$ans" = "yes" ]; then
        rm -rf backups
        echo "[ok] backups deleted"
    else
        echo "backups kept"
    fi
fi
