#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include "vault.h"

/* Read a password without showing it on screen */
static void read_password(const char *prompt, char *buf, int size)
{
    struct termios oldt, newt;

    printf("%s", prompt);
    fflush(stdout);

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    if (fgets(buf, size, stdin) == NULL)
        buf[0] = '\0';

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\n");

    buf[strcspn(buf, "\n")] = '\0';
}

int vault_init(void)
{
    char pw1[128], pw2[128];
    VaultHeader hdr;
    FileEntry empty;
    int fd, i;

    /* O_EXCL fails if the file already exists. 0600 = owner read/write only */
    fd = open(VAULT_FILE, O_CREAT | O_EXCL | O_RDWR, 0600);
    if (fd < 0) {
        if (errno == EEXIST)
            fprintf(stderr, "Error: %s already exists.\n", VAULT_FILE);
        else
            perror("open");
        return -1;
    }

    read_password("Set vault password: ", pw1, sizeof(pw1));
    read_password("Confirm password: ", pw2, sizeof(pw2));

    if (strlen(pw1) == 0 || strcmp(pw1, pw2) != 0) {
        fprintf(stderr, "Error: passwords empty or do not match.\n");
        close(fd);
        unlink(VAULT_FILE);
        return -1;
    }

    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, MAGIC, 8);
    generate_salt(hdr.salt, SALT_LEN);
    hash_password(pw1, hdr.salt, hdr.pass_hash);
    hdr.file_count = 0;

    if (write(fd, &hdr, sizeof(hdr)) != sizeof(hdr)) {
        perror("write header");
        close(fd);
        return -1;
    }

    memset(&empty, 0, sizeof(empty));
    for (i = 0; i < MAX_FILES; i++) {
        if (write(fd, &empty, sizeof(empty)) != sizeof(empty)) {
            perror("write table");
            close(fd);
            return -1;
        }
    }

    /* Wipe passwords from memory */
    memset(pw1, 0, sizeof(pw1));
    memset(pw2, 0, sizeof(pw2));

    close(fd);
    printf("Vault created: %s (permissions 600)\n", VAULT_FILE);
    return 0;
}

/* ---------- helpers using only system calls ---------- */

static int write_all(int fd, const void *buf, size_t n)
{
    const char *p = buf;
    while (n > 0) {
        ssize_t w = write(fd, p, n);
        if (w < 0) return -1;
        p += w;
        n -= w;
    }
    return 0;
}

static int read_all(int fd, void *buf, size_t n)
{
    char *p = buf;
    while (n > 0) {
        ssize_t r = read(fd, p, n);
        if (r <= 0) return -1;
        p += r;
        n -= r;
    }
    return 0;
}

/* Open vault and load header + file table */
static int load_vault(int flags, VaultHeader *hdr, FileEntry *table)
{
    int fd = open(VAULT_FILE, flags);
    if (fd < 0) {
        perror("open vault");
        return -1;
    }
    if (read_all(fd, hdr, sizeof(*hdr)) < 0 ||
        memcmp(hdr->magic, MAGIC, 8) != 0 ||
        read_all(fd, table, sizeof(FileEntry) * MAX_FILES) < 0) {
        fprintf(stderr, "Error: not a valid vault file.\n");
        close(fd);
        return -1;
    }
    return fd;
}

/* ---------- login (now also returns the key) ---------- */

int vault_login(unsigned char *key)
{
    char pw[128];
    unsigned char computed[HASH_LEN];
    VaultHeader hdr;
    int fd, ok;

    fd = open(VAULT_FILE, O_RDONLY);
    if (fd < 0) {
        perror("open vault");
        return -1;
    }

    if (read_all(fd, &hdr, sizeof(hdr)) < 0 ||
        memcmp(hdr.magic, MAGIC, 8) != 0) {
        fprintf(stderr, "Error: not a valid vault file.\n");
        close(fd);
        return -1;
    }
    close(fd);

    read_password("Vault password: ", pw, sizeof(pw));
    hash_password(pw, hdr.salt, computed);

    ok = hash_equal(computed, hdr.pass_hash, HASH_LEN);
    if (ok && key != NULL)
        derive_key(pw, hdr.salt, key);
    memset(pw, 0, sizeof(pw));

    if (!ok) {
        fprintf(stderr, "Access denied: wrong password.\n");
        return -1;
    }
    printf("Access granted.\n");
    return 0;
}

/* ---------- add ---------- */

int vault_add(const char *path, const unsigned char *key)
{
    VaultHeader hdr;
    FileEntry table[MAX_FILES];
    unsigned char buf[CHUNK_SIZE];
    const char *name;
    int vfd, sfd, slot = -1, i;
    long start, total = 0;
    ssize_t n;

    /* store only the file name, not the folder path */
    name = strrchr(path, '/');
    name = name ? name + 1 : path;

    if (strlen(name) == 0 || strlen(name) >= NAME_LEN) {
        fprintf(stderr, "Error: invalid file name.\n");
        return -1;
    }

    vfd = load_vault(O_RDWR, &hdr, table);
    if (vfd < 0) return -1;

    for (i = 0; i < MAX_FILES; i++) {
        if (table[i].used && strcmp(table[i].name, name) == 0) {
            fprintf(stderr, "Error: '%s' is already in the vault.\n", name);
            close(vfd);
            return -1;
        }
        if (!table[i].used && slot < 0)
            slot = i;
    }
    if (slot < 0) {
        fprintf(stderr, "Error: vault is full (%d files).\n", MAX_FILES);
        close(vfd);
        return -1;
    }

    sfd = open(path, O_RDONLY);
    if (sfd < 0) {
        perror("open source file");
        close(vfd);
        return -1;
    }

    /* data goes at the end of the vault */
    start = lseek(vfd, 0, SEEK_END);

    while ((n = read(sfd, buf, sizeof(buf))) > 0) {
        encrypt_buffer(buf, (int)n, key, start + total);
        if (write_all(vfd, buf, n) < 0) {
            perror("write vault");
            ftruncate(vfd, start);          /* undo partial data */
            close(sfd); close(vfd);
            return -1;
        }
        total += n;
    }
    if (n < 0) {
        perror("read source file");
        ftruncate(vfd, start);
        close(sfd); close(vfd);
        return -1;
    }
    close(sfd);

    /* fill the table entry */
    memset(&table[slot], 0, sizeof(FileEntry));
    strncpy(table[slot].name, name, NAME_LEN - 1);
    table[slot].size   = total;
    table[slot].offset = start;
    table[slot].used   = 1;
    hdr.file_count++;

    /* write header and table back to the start of the vault */
    lseek(vfd, 0, SEEK_SET);
    if (write_all(vfd, &hdr, sizeof(hdr)) < 0 ||
        write_all(vfd, table, sizeof(table)) < 0) {
        perror("write metadata");
        close(vfd);
        return -1;
    }

    close(vfd);
    printf("Added '%s' (%ld bytes) to the vault.\n", name, total);
    return 0;
}

/* ---------- list ---------- */

int vault_list(void)
{
    VaultHeader hdr;
    FileEntry table[MAX_FILES];
    int fd, i, shown = 0;

    fd = load_vault(O_RDONLY, &hdr, table);
    if (fd < 0) return -1;
    close(fd);

    printf("\n%-4s %-30s %10s\n", "No.", "Name", "Size (bytes)");
    printf("---- ------------------------------ ------------\n");
    for (i = 0; i < MAX_FILES; i++) {
        if (table[i].used) {
            printf("%-4d %-30s %10ld\n", ++shown, table[i].name, table[i].size);
        }
    }
    if (shown == 0)
        printf("(vault is empty)\n");
    printf("\nTotal files: %d\n", shown);
    return 0;
}

/* ---------- extract ---------- */

int vault_extract(const char *name, const unsigned char *key)
{
    VaultHeader hdr;
    FileEntry table[MAX_FILES];
    unsigned char buf[CHUNK_SIZE];
    int vfd, ofd, i, found = -1;
    long done = 0;

    vfd = load_vault(O_RDONLY, &hdr, table);
    if (vfd < 0) return -1;

    for (i = 0; i < MAX_FILES; i++) {
        if (table[i].used && strcmp(table[i].name, name) == 0) {
            found = i;
            break;
        }
    }
    if (found < 0) {
        fprintf(stderr, "Error: '%s' not found in the vault.\n", name);
        close(vfd);
        return -1;
    }

    /* O_EXCL: never overwrite an existing file by accident */
    ofd = open(name, O_CREAT | O_EXCL | O_WRONLY, 0600);
    if (ofd < 0) {
        if (errno == EEXIST)
            fprintf(stderr, "Error: '%s' already exists here. "
                            "Move or rename it first.\n", name);
        else
            perror("create output file");
        close(vfd);
        return -1;
    }

    lseek(vfd, table[found].offset, SEEK_SET);

    while (done < table[found].size) {
        long want = table[found].size - done;
        if (want > CHUNK_SIZE) want = CHUNK_SIZE;

        if (read_all(vfd, buf, want) < 0) {
            fprintf(stderr, "Error: vault data is damaged.\n");
            close(vfd); close(ofd);
            unlink(name);
            return -1;
        }
        decrypt_buffer(buf, (int)want, key, table[found].offset + done);
        if (write_all(ofd, buf, want) < 0) {
            perror("write output");
            close(vfd); close(ofd);
            unlink(name);
            return -1;
        }
        done += want;
    }

    close(vfd);
    close(ofd);
    printf("Extracted '%s' (%ld bytes).\n", name, done);
    return 0;
}
