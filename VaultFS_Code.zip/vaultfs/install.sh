#!/bin/bash
# Checks tools, compiles the project and sets permissions

cd "$(dirname "$0")" || exit 1

echo "== VaultFS installer =="

for tool in gcc make tar; do
    if ! command -v "$tool" > /dev/null 2>&1; then
        echo "Error: '$tool' is not installed."
        echo "Run: sudo apt install build-essential"
        exit 1
    fi
done
echo "[ok] gcc, make and tar found"

make clean > /dev/null 2>&1
if make; then
    echo "[ok] compiled successfully"
else
    echo "Error: compilation failed."
    exit 1
fi

chmod 700 vaultfs vault_backup.sh install.sh cleanup.sh 2>/dev/null
[ -f vault.bin ] && chmod 600 vault.bin
echo "[ok] permissions set"

echo "Done. Next: ./vaultfs -i   (if you have no vault yet)"
