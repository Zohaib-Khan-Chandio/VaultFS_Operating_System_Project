#include <stdio.h>
#include <unistd.h>
#include "vault.h"

static void usage(const char *prog)
{
    printf("VaultFS - encrypted file vault\n\n");
    printf("Usage: %s <option>\n", prog);
    printf("  -i            initialize a new vault\n");
    printf("  -a <file>     add a file to the vault\n");
    printf("  -l            list files in the vault\n");
    printf("  -e <file>     extract a file from the vault\n");
    printf("  -t            test password login only\n");
    printf("  -h            show this help\n");
}

int main(int argc, char *argv[])
{
    unsigned char key[HASH_LEN];
    int opt;
    int action = 0;
    const char *arg = NULL;

    while ((opt = getopt(argc, argv, "ia:le:th")) != -1) {
        switch (opt) {
        case 'h':
            usage(argv[0]);
            return 0;
        case 'i':
        case 'a':
        case 'l':
        case 'e':
        case 't':
            if (action) {
                fprintf(stderr, "Error: use only one option at a time.\n");
                return 1;
            }
            action = opt;
            arg = optarg;
            break;
        default:               /* unknown option or missing argument */
            usage(argv[0]);
            return 1;
        }
    }

    /* no option given, or leftover words like "./vaultfs -l extra" */
    if (action == 0 || optind < argc) {
        usage(argv[0]);
        return 1;
    }

    if (action == 'i')
        return vault_init() == 0 ? 0 : 1;

    /* every other action needs the password first */
    if (vault_login(key) != 0)
        return 1;

    switch (action) {
    case 'a': return vault_add(arg, key) == 0 ? 0 : 1;
    case 'l': return vault_list() == 0 ? 0 : 1;
    case 'e': return vault_extract(arg, key) == 0 ? 0 : 1;
    case 't': return 0;
    }
    return 1;
}
