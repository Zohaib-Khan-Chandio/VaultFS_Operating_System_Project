#!/bin/bash
# Creates a secure compressed backup of vault.bin

cd "$(dirname "$0")" || exit 1

VAULT="vault.bin"
BACKUP_DIR="backups"
STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="$BACKUP_DIR/vault_backup_$STAMP.tar.gz"

if [ ! -f "$VAULT" ]; then
    echo "Error: $VAULT not found. Run ./vaultfs -i first."
    exit 1
fi

# umask 077 means new files and folders are never readable by others
umask 077
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

if tar -czf "$BACKUP" "$VAULT"; then
    chmod 600 "$BACKUP"
    echo "Backup created: $BACKUP"
    ls -l "$BACKUP"
else
    echo "Error: backup failed."
    exit 1
fi
