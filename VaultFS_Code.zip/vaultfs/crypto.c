#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include "vault.h"

/* Fill salt with random bytes from the kernel */
void generate_salt(unsigned char *salt, int len)
{
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd >= 0) {
        read(fd, salt, len);
        close(fd);
    }
}

/* Simple salted hash: runs FNV-1a many times and spreads into 32 bytes */
void hash_password(const char *password, const unsigned char *salt,
                   unsigned char *out_hash)
{
    unsigned long long h = 1469598103934665603ULL;
    int i, round;

    for (i = 0; i < HASH_LEN; i++)
        out_hash[i] = 0;

    for (round = 0; round < 10000; round++) {
        for (i = 0; i < SALT_LEN; i++) {
            h ^= salt[i];
            h *= 1099511628211ULL;
        }
        for (i = 0; password[i]; i++) {
            h ^= (unsigned char)password[i];
            h *= 1099511628211ULL;
        }
        out_hash[round % HASH_LEN] ^= (unsigned char)(h >> ((round % 8) * 8));
    }
}

/* Compare two hashes without stopping early */
int hash_equal(const unsigned char *a, const unsigned char *b, int len)
{
    unsigned char diff = 0;
    for (int i = 0; i < len; i++)
        diff |= a[i] ^ b[i];
    return diff == 0;

}

/* Key derived with a different salt than the stored password hash */
void derive_key(const char *password, const unsigned char *salt,
                unsigned char *key)
{
    unsigned char salt2[SALT_LEN];
    for (int i = 0; i < SALT_LEN; i++)
        salt2[i] = salt[i] ^ 0xA5;
    hash_password(password, salt2, key);
}

/* Mixing function used to make a keystream (splitmix64) */
static unsigned long long mix(unsigned long long z)
{
    z += 0x9e3779b97f4a7c15ULL;
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

/* Stream cipher: XOR each byte with a keystream byte.
   'pos' is the byte position in the vault, so encrypting in
   chunks gives the same result as encrypting all at once. */
void encrypt_buffer(unsigned char *buf, int len,
                    const unsigned char *key, long pos)
{
    unsigned long long seed = 1469598103934665603ULL;
    for (int i = 0; i < HASH_LEN; i++)
        seed = (seed * 1099511628211ULL) ^ key[i];

    for (int i = 0; i < len; i++) {
        unsigned long long p = (unsigned long long)(pos + i);
        buf[i] ^= (unsigned char)(mix(seed + p) & 0xFF);
    }
}

/* XOR is symmetric, so decrypting is the same operation */
void decrypt_buffer(unsigned char *buf, int len,
                    const unsigned char *key, long pos)
{
    encrypt_buffer(buf, len, key, pos);
}
